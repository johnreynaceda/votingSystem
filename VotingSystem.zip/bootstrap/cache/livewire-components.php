<?php return array (
  'campus' => 'App\\Http\\Livewire\\Campus',
  'organization' => 'App\\Http\\Livewire\\Organization',
  'partylist' => 'App\\Http\\Livewire\\Partylist',
);