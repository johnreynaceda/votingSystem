<div>
    <div x-data="{ show: <?php if ((object) ('addModal') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('addModal'->value()); ?>')<?php echo e('addModal'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('addModal'); ?>') <?php endif; ?> }" class="flex justify-end items-center mb-3">
        <div wire:click.prevent="add" class="bg-nav px-6 text-white p-2 rounded-full space-x-2 shadow-md cursor-pointer hover:bg-green-500 flex">
            <i class="material-icons md-32">person_add</i>
            <h1>Add Student</h1>
        </div>
        <div tabindex="0" class="z-40 overflow-auto left-0 top-0 bottom-0 right-0 w-full h-full fixed" style="background-color: rgba(0,0,0,.5);" x-show="show">
            <div class="text-left bg-white h-auto mx-72  mt-6" @click.away="show = false">
                <div class="flex bg-nav text-white">
                    <div class=" px-3 py-2 font-medium text-lg w-11/12">
                     <h1>Add Student</h1>
                 </div>
                    <div class=" flex justify-center items-center w-1/12">
                     <div @click="show = false" class="hover:bg-red-600 p-1 cursor-pointer rounded-full flex justify-center items-center"><i class="material-icons">close</i></div>
                 </div>
                </div>
                <div class="body bg-white text-side ">
                    <form class="flex space-x-7 py-2 px-4" action="">
                        <div class="w-6/12">
                            <div class="mb-2 text-side">
                                <label for="">Firstname:</label>
                                <input wire:model="firstname" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Firstname">
                                <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-2 text-side">
                                <label for="">Middlename:</label>
                                <input wire:model="middlename" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Middlename">
                                <?php $__errorArgs = ['middlename'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-2 text-side">
                                <label for="">Lastname:</label>
                                <input wire:model="lastname" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Lastname">
                                <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-2 text-side">
                                <label for="">Address:</label>
                                <input wire:model="address" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Address">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-2 text-side">
                                <label for="">Birthdate:</label>
                                <input wire:model="birthdate" type="date" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Lastname">
                                <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-2 text-side">
                                <label for="">Age:</label>
                                <input wire:model="age" type="number" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Age">
                                <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-2 text-side">
                                <label for="">Contact:</label>
                                <input wire:model="contact" type="number" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="09123456789">
                                <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class=" w-6/12">
                            <div class="mb-2 text-side">
                                <label for="">Campus:</label>
                                <select wire:model="campus" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Lastname">
                                    <option selected hidden disabled value="null">Select Campus</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $campuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->campus); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled value="">No Campus Available</option>
                                    <?php endif; ?>
                                </select> 
                                <?php $__errorArgs = ['campus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                            </div>
                            <div class="mb-2 text-side">
                                <label for="">Organization:</label>
                                <div class="border mt-1 rounded-sm h-24 overflow-y-auto">
                                    <div class=" grid mt-1  px-3 rounded-sm grid-cols-3 gap-2">
                                        <?php $__empty_1 = true; $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <label class="inline-flex items-center">
                                            <input wire:model="organization" type="checkbox" value="<?php echo e($item->id); ?>" class="form-checkbox">
                                            <span class="ml-2"><?php echo e($item->organization); ?></span>
                                          </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <label for="">No Organization Data!</label>
                                        <?php endif; ?>
                                        
                                      </div>
                                </div>
                                
                            </div>
                            <div class="mb-2 text-side">
                                <label for="">Course:</label>
                                <input wire:model="course" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Course">
                                <?php $__errorArgs = ['course'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-2 text-side">
                                <label for="">Email:</label>
                                <input wire:model="email" type="mail" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-2 text-side">
                                <label for="">Student ID Number:</label>
                                <input wire:model="sidn" type="number" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="53598">
                                <?php $__errorArgs = ['sidn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-2 flex justify-end">
                               <button wire:click.prevent="save" class="bg-nav focus:outline-none flex rounded-md shadow-md text-white hover:bg-green-600 cursor-pointer p-2">
                                 
                                   <i class="material-icons">save</i>
                                   <h1 class="ml-1">SAVE</h1>
                               </button>
                               
                             </div>
                        </div>
                    </form>
                   </div>
               </div>
            </div>
    </div>
    <div class="flex">
        <div class=" flex items-center w-6/12">
         <div class="bg-green-300 border-r  w-11/12"><input class="h-10 border border-green-600 focus:border-side w-full outline-none px-3" type="text" name="" id="" placeholder="Search Student"></div>
         <div class="bg-nav text-white border border-green-600 flex justify-center items-center h-full w-1/12"><i class="material-icons md-36">search</i></div>
     </div>
        <div class=" w-6/12">
     </div>
    </div>
    <div class="tbl mt-4">
        <div class="bg-nav font-medium text-white p-2">
            <h1>List of Students</h1>
        </div>
        <div class="body mt-1 shadow-md">
         <table class="text-left w-full border-collapse "> <!--Border collapse doesn't work on this site yet but it's available in newer tailwind versions -->
             <thead class="bg-side text-white">
               <tr class="">
                 <th width="10" class="py-2 px-2 b font-bold uppercase text-xs text-grey-dark border-b border-grey-light">#</th>
                 <th width="250" class="py-2 px-2 b font-bold uppercase text-xs text-grey-dark border-b border-grey-light">FULLNAME</th>
                 <th width="100" class="py-2 px-2 b font-bold uppercase text-xs text-grey-dark border-b border-grey-light">SIDN</th>
                 <th class="py-2 px-2 b font-bold uppercase text-xs text-grey-dark border-b border-grey-light">COURSE</th>
                 <th class="py-2 px-2 b font-bold uppercase text-xs text-grey-dark border-b border-grey-light">ORGANIZATION</th>
                 <th class="py-2 px-2 b font-bold uppercase text-xs text-grey-dark border-b border-grey-light">CAMPUS</th>
                 <th width="100" class="py-2 px-2 b font-bold uppercase text-xs text-grey-dark border-b border-grey-light">ACTIONS</th>
               </tr>
             </thead>
             <tbody>
                <?php $i = 1; ?>
               <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <tr class="hover:bg-gray-200">
                <td class="py-1 px-1 border-b border-side"><?php echo e($i++); ?></td>
                <td class="py-1 px-1 border-b border-side"><?php echo e($user->lastname.", ".$user->firstname." ".$user->middlename[0]."."); ?></td>
                <td class="py-1 px-1 border-b border-side"><?php echo e($user->sidn); ?></td>
                <td class="py-1 px-1 border-b border-side"><?php echo e($user->course); ?></td>
                <td class="py-1 px-1 border-b border-side">
                    <?php $__currentLoopData = $user->organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <ul>
                           <li><?php echo e($organization->organization); ?></li>
                       </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td class="py-1 px-1 border-b border-side"><?php echo e($user->campus->campus); ?> CAMPUS</td>
                <td class="py-1 px-1 border-b border-side">
                  <div x-data="{ show: <?php if ((object) ('editModal') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('editModal'->value()); ?>')<?php echo e('editModal'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('editModal'); ?>') <?php endif; ?> }" class="flex cursor-pointer">
                    <div wire:click.prevent="edit()" class="bg-print hover:bg-yellow-500 w-6/12 flex items-center justify-center border-r rounded-tl rounded-bl text-white h-8"><i class="material-icons">edit</i></div>
                    <div tabindex="0" class="z-40 overflow-auto left-0 top-0 bottom-0 right-0 w-full h-full fixed" style="background-color: rgba(0,0,0,.5);" x-show="show">
                       <div class="text-left bg-white h-auto mx-72  mt-10" @click.away="show = false">
                           <div class="flex bg-nav text-white">
                               <div class=" px-3 py-2 font-medium text-lg w-11/12">
                                <h1>Update Student</h1>
                            </div>
                               <div class=" flex justify-center items-center w-1/12">
                                <div @click="show = false" class="hover:bg-red-600 p-1 rounded-full flex justify-center items-center"><i class="material-icons">close</i></div>
                            </div>
                           </div>
                           <div class="body bg-white text-side ">
                               <form class="flex space-x-7 py-2 px-4" action="">
                                   <div class="w-6/12">
                                       <div class="mb-2 text-side">
                                           <label for="">Firstname:</label>
                                           <input wire:model="firstname" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Firstname">
                                           <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <?php echo e($this->firstname); ?>

                                       <div class="mb-2 text-side">
                                           <label for="">Middlename:</label>
                                           <input wire:model="middlename" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Middlename">
                                           <?php $__errorArgs = ['middlename'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <div class="mb-2 text-side">
                                           <label for="">Lastname:</label>
                                           <input wire:model="lastname" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Lastname">
                                           <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <div class="mb-2 text-side">
                                           <label for="">Address:</label>
                                           <input wire:model="firstname" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Address">
                                       </div>
                                       <div class="mb-2 text-side">
                                           <label for="">Birthdate:</label>
                                           <input wire:model="address" type="date" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Lastname">
                                           <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <div class="mb-2 text-side">
                                           <label for="">Age:</label>
                                           <input wire:model="age" type="number" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Age">
                                           <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <div class="mb-2 text-side">
                                           <label for="">Contact:</label>
                                           <input wire:model="contact" type="number" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="09123456789">
                                           <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                   </div>
                                   <div class=" w-6/12">
                                       <div class="mb-2 text-side">
                                           <label for="">Organization:</label>
                                           <select wire:model="organization" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Lastname">
                                               <option selected hidden disabled value="null">Select Organization</option>
                                               <?php $__empty_2 = true; $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                               <option value="<?php echo e($item->id); ?>"><?php echo e($item->organization); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                               <option disabled value="">No Organization Available</option>
                                               <?php endif; ?>
                                           </select>
                                           <?php $__errorArgs = ['organization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <div class="mb-2 text-side">
                                           <label for="">Course:</label>
                                           <input wire:model="course" type="number" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Course">
                                           <?php $__errorArgs = ['course'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <div class="mb-2 text-side">
                                           <label for="">Email:</label>
                                           <input wire:model="email" type="mail" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Email">
                                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <div class="mb-2 text-side">
                                           <label for="">Password:</label>
                                           <input wire:model="password" type="password" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Password">
                                           <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <div class="mb-2 text-side">
                                           <label for="">Student ID Number:</label>
                                           <input wire:model="sidn" type="number" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="53598">
                                           <?php $__errorArgs = ['sidn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       </div>
                                       <div class="mb-5 text-side">
                                           <label for="">Campus:</label>
                                           <select wire:model="campus" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Lastname">
                                               <option selected hidden disabled value="null">Select Campus</option>
                                               <?php $__empty_2 = true; $__currentLoopData = $campuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                               <option value="<?php echo e($item->id); ?>"><?php echo e($item->campus); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                               <option disabled value="">No Campus Available</option>
                                               <?php endif; ?>
                                           </select> 
                                           <?php $__errorArgs = ['campus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                       </div>
                                       <div class="mb-2 flex justify-end">
                                          <button wire:click.prevent="saveedit" class="bg-nav focus:outline-none flex rounded-md shadow-md text-white hover:bg-green-600 cursor-pointer p-2">
                                            
                                              <i class="material-icons">save</i>
                                              <h1 class="ml-1">SAVE</h1>
                                          </button>
                                          
                                        </div>
                                   </div>
                               </form>
                              </div>
                          </div>
                       </div>
                    <div class="bg-red-600 hover:bg-red-800 w-6/12 flex items-center rounded-tr rounded-br justify-center text-white h-8"><i class="material-icons">delete</i></div>
                  </div>
                </td>
            </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <tr>
                       <td colspan="7" class="py-1 px-1 border-b text-center border-side">
                        <h1>No Students Data!</h1>
                       </td>
                   </tr>
               <?php endif; ?>
              
               
             </tbody>
           </table>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/livewire/admin/student/student.blade.php ENDPATH**/ ?>