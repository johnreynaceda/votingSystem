
<?php $__env->startSection('content'); ?>
    <div class="flex space-x-2 border-b border-green-500 items-center text-nav">
        <i class="material-icons md-36">view_column</i>
        <h1 class="text-xl font-medium ">Organization</h1>
    </div>
    <div class="main-body mt-4">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('organization')->html();
} elseif ($_instance->childHasBeenRendered('nhHliIm')) {
    $componentId = $_instance->getRenderedChildComponentId('nhHliIm');
    $componentTag = $_instance->getRenderedChildComponentTagName('nhHliIm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nhHliIm');
} else {
    $response = \Livewire\Livewire::mount('organization');
    $html = $response->html();
    $_instance->logRenderedChild('nhHliIm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/admin/organization.blade.php ENDPATH**/ ?>