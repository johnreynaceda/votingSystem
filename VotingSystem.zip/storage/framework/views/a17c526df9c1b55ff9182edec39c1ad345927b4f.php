
<?php $__env->startSection('content'); ?>
<div class="flex space-x-2 border-b border-green-500 items-center text-nav">
    <i class="material-icons md-36">view_module</i>
    <h1 class="text-xl font-medium ">Party-list</h1>
</div>
<div class="main-body mt-4">
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('partylist')->html();
} elseif ($_instance->childHasBeenRendered('Tt3Ohzf')) {
    $componentId = $_instance->getRenderedChildComponentId('Tt3Ohzf');
    $componentTag = $_instance->getRenderedChildComponentTagName('Tt3Ohzf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Tt3Ohzf');
} else {
    $response = \Livewire\Livewire::mount('partylist');
    $html = $response->html();
    $_instance->logRenderedChild('Tt3Ohzf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/admin/party-list.blade.php ENDPATH**/ ?>