<div>
   <div class="flex items-center space-x-3">
    <h1 class="text-gray-600">: Please select organization to manage.</h1>
   
    <select wire:model="organization_id" class="h-8  outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Lastname">
       
        <option selected hidden disabled value="null">Select Organization</option>
         <?php $__empty_1 = true; $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <option value="<?php echo e($organization->id); ?>"><?php echo e($organization->organization); ?>-<?php echo e($organization->campus->campus); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <option disabled value="">No Organization Available</option>
         <?php endif; ?>
    </select> 
    <?php $__errorArgs = ['campus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
   </div>
   
       <?php if($this->organization_id == null): ?>
       <?php else: ?>
       <div class=" mt-2 font-medium underline text-side text-xl">
       <h1><?php echo e($this->manage->organization); ?>-<?php echo e($this->manage->campus->campus); ?></h1>
        </div>
        <div x-data="{ show: <?php if ((object) ('addModal') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('addModal'->value()); ?>')<?php echo e('addModal'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('addModal'); ?>') <?php endif; ?> }" class="flex mt-2">
            <div wire:click="add" class="bg-nav flex cursor-pointer hover:bg-green-600 p-2 rounded-full shadow-md text-white px-3 space-x-2">
                <i class="material-icons">person_add</i>
                <h1>Add Candidate</h1>
            </div>
            <div tabindex="0" class="z-40 overflow-auto left-0 top-0 bottom-0 right-0 w-full h-full fixed" style="background-color: rgba(0,0,0,.5);" x-show="show">
                <div class="text-left bg-white h-auto mx-72  mt-6" @click.away="show = false">
                    <div class="flex bg-nav text-white">
                        <div class=" px-3 py-2 font-medium text-lg w-11/12">
                         <h1>Add Candidate</h1>
                     </div>
                        <div class=" flex justify-center items-center w-1/12">
                         <div @click="show = false" class="hover:bg-red-600 p-1 cursor-pointer rounded-full flex justify-center items-center"><i class="material-icons">close</i></div>
                     </div>
                    </div>
                    <div class="body bg-white text-side ">
                        <form class="flex space-x-7 py-2 px-4">
                            <?php echo csrf_field(); ?>
                            <div class="w-6/12">
                                <div class="mb-2 text-side">
                                    <label for="">Student:</label>
                                    <?php echo e($student_id); ?>

                                   <div class="flex space-x-2 items-center">
                                    <input wire:model="fullname" type="text" class="h-8 w-10/12 outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Student">
                                    <div class="w-2/12  ">
                                        <div wire:click.prevent="searchStud" wire:key="searchStud" class="bg-nav mt-1 cursor-pointer hover:bg-green-600 p-1 text-white flex justify-center rounded-sm">
                                            <i class="material-icons">search</i>
                                        </div>
                                    </div>
                                   </div>
                                   <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   <?php if($this->searchStudent == false): ?>

                                       <?php else: ?>
                                       <div class="rounded-sm p-1 border mt-1">
                                           <div class="flex mb-1 p-1">
                                               <div class="w-10/12">
                                                <input wire:model="search" type="text" class="h-8  w-full outline-none focus:border-green-400 text-sm px-3  focus:shadow-md rounded-sm border" placeholder="Search Student">
                                                </div>
                                               <div class="border w-2/12 flex justify-center items-center">
                                                <i class="material-icons">search</i>
                                                </div>
                                           </div>
                                        <?php $__empty_1 = true; $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="flex space-x-2">
                                            <div class="w-10/12 border-b">
                                         <h1><?php echo e($item->lastname.", ".$item->firstname." ".$item->middlename[0]."."); ?></h1>
                                             </div>
                                            <div class="w-2/12">
                                         <div wire:click="getStud(<?php echo e($item->id); ?>)" class="flex bg-side text-white rounded-sm cursor-pointer hover:bg-gray-600 justify-center items-center ">
                                             <i class="material-icons">playlist_add_check</i>
                                         </div>
                                             </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            
                                        <?php endif; ?>
                                    </div>
                                   <?php endif; ?>
                                </div>
                                <?php if($this->isdependent == 1): ?>
                                    <?php else: ?>
                                    <div class="mb-2 text-side">
                                        <label for="">Partylist:</label>
                                        <?php echo e($party_id); ?>

                                       <div class="flex space-x-2 items-center">
                                        <input wire:model="partylist_name" type="text" class="h-8 w-10/12 outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Partylist">
                                        <div class="w-2/12  ">
                                            <div wire:click.prevent="searchPartylist"  class="bg-nav mt-1 cursor-pointer hover:bg-green-600 p-1 text-white flex justify-center rounded-sm">
                                                <i class="material-icons">search</i>
                                            </div>
                                        </div>
                                       </div>
                                       <?php $__errorArgs = ['partylist_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       <?php if($this->searchParty == false): ?>
    
                                           <?php else: ?>
                                           <div class="rounded-sm p-1 border mt-1">
                                               <div class="flex mb-1 p-1">
                                                   <div class="w-10/12">
                                                    <input wire:model="search" type="text" class="h-8  w-full outline-none focus:border-green-400 text-sm px-3  focus:shadow-md rounded-sm border" placeholder="Search Partylist">
                                                    </div>
                                                   <div class="border w-2/12 flex justify-center items-center">
                                                    <i class="material-icons">search</i>
                                                    </div>
                                               </div>
                                            <?php $__empty_1 = true; $__currentLoopData = $partylist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="flex space-x-2">
                                                <div class="w-10/12 border-b">
                                             <h1><?php echo e($item->partylist); ?>-Partylist</h1>
                                                 </div>
                                                <div class="w-2/12">
                                             <div wire:click="getParty(<?php echo e($item->id); ?>)" class="flex bg-side text-white rounded-sm cursor-pointer hover:bg-gray-600 justify-center items-center ">
                                                 <i class="material-icons">playlist_add_check</i>
                                             </div>
                                                 </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                
                                            <?php endif; ?>
                                        </div>
                                       <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <div class="mb-2 text-side">
                                    <label for="">Position:</label>
                                    <select wire:model="position_id" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" >
                                        <option selected hidden disabled value="null">Select Position</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->position); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option disabled value="">No Position Available</option>
                                        <?php endif; ?>
                                    </select> 
                                    <?php $__errorArgs = ['position_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                </div>
                                <div class="mb-2 text-side">
                                    <label class="inline-flex items-center mt-3">
                                        <input wire:model="isdependent" value="1" type="checkbox" class="form-checkbox h-5 w-5 text-nav" ><span class="ml-2 text-gray-700">Dependent</span>
                                    </label>
                                </div>
                               
                            </div>
                            <div class=" w-6/12">
                                <div class="mb-2 text-side">
                                    <label for="">Image:</label>
                                    <?php if($photo): ?>
                                   <div class="border border-nav h-96 rounded-sm shadow-lg mb-1">
                                    <img src="<?php echo e($photo->temporaryUrl()); ?>" class="h-96">
                                   </div>
                                   <?php else: ?>
                                   <div class="border flex relative h-96 shadow-lg rounded-sm mb-1"></div>
                                <?php endif; ?>

                                <div class="relative">
                                    <input type="file" wire:model="photo">
                                </div>

                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                
                                
                                <div class="mb-2 flex justify-end">
                                    <div  wire:loading wire:target="save">
                                        <div class="loadingio-spinner-dual-ball-7d9kijy1d27"><div class="ldio-es4i676yvyv">
                                            <div></div><div></div><div></div>
                                            </div></div>
                                        </div>
                                   <button wire:click.prevent="save" class="bg-nav focus:outline-none mt-1 flex rounded-md shadow-md text-white hover:bg-green-600 cursor-pointer p-2">
                                     
                                       <i class="material-icons">save</i>
                                       <h1 class="ml-1">SAVE</h1>
                                   </button>
                                   
                                 </div>
                            </div>
                        </form>
                       </div>
                   </div>
                </div>
        </div>
           <?php echo $__env->make('livewire.admin.candidate.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <?php endif; ?>
      
</div>
<?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/livewire/admin/candidate/candidate.blade.php ENDPATH**/ ?>