
<?php $__env->startSection('content'); ?>
<div class="flex space-x-2 border-b  border-green-500 items-center text-nav">
    <i class="material-icons md-36">dashboard</i>
    <h1 class="text-xl font-medium ">Dashboard</h1>
</div>
<div class="main-body mt-2">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-dashboard')->html();
} elseif ($_instance->childHasBeenRendered('Cr01QSl')) {
    $componentId = $_instance->getRenderedChildComponentId('Cr01QSl');
    $componentTag = $_instance->getRenderedChildComponentTagName('Cr01QSl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Cr01QSl');
} else {
    $response = \Livewire\Livewire::mount('admin-dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('Cr01QSl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>