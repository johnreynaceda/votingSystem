
<?php $__env->startSection('content'); ?>
<div class="flex space-x-2 border-b border-green-500 items-center text-nav">
    <i class="material-icons md-36">domain</i>
    <h1 class="text-xl font-medium ">Campus</h1>
</div>
<div class="main-body mt-4">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('campus')->html();
} elseif ($_instance->childHasBeenRendered('qdLQ2fk')) {
    $componentId = $_instance->getRenderedChildComponentId('qdLQ2fk');
    $componentTag = $_instance->getRenderedChildComponentTagName('qdLQ2fk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qdLQ2fk');
} else {
    $response = \Livewire\Livewire::mount('campus');
    $html = $response->html();
    $_instance->logRenderedChild('qdLQ2fk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/admin/campus.blade.php ENDPATH**/ ?>