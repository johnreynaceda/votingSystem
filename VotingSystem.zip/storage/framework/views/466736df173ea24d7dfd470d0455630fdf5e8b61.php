
<?php $__env->startSection('content'); ?>
<div class="flex space-x-2 border-b border-green-500 items-center text-nav">
    <i class="material-icons md-36">supervised_user_circle</i>
    <h1 class="text-xl font-medium ">Users</h1>
</div>
<div class="main-body mt-4">
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user')->html();
} elseif ($_instance->childHasBeenRendered('z7LLj4P')) {
    $componentId = $_instance->getRenderedChildComponentId('z7LLj4P');
    $componentTag = $_instance->getRenderedChildComponentTagName('z7LLj4P');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('z7LLj4P');
} else {
    $response = \Livewire\Livewire::mount('user');
    $html = $response->html();
    $_instance->logRenderedChild('z7LLj4P', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/admin/user.blade.php ENDPATH**/ ?>