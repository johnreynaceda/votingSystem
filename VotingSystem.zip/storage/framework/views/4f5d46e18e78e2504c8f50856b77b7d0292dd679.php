
<?php $__env->startSection('content'); ?>
<div class="main  relative">
    <div class=" px-2 mt-3 flex justify-end space-x-2">
        <form method="POST" class="flex space-x-2" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
   
    <a href="<?php echo e(route('logout')); ?>"
    onclick="event.preventDefault();
                this.closest('form').submit();">
        <div class="flex border p-1 space-x-2 px-4 rounded-full bg-nav text-white  hover:bg-green-600  cursor-pointer border-gray-400 shadow-md">
            <i class="material-icons">logout</i>
            <h1 class="">Sign-out</h1>
        </div>
    </a>
        </form>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('account')->html();
} elseif ($_instance->childHasBeenRendered('hqhEU9d')) {
    $componentId = $_instance->getRenderedChildComponentId('hqhEU9d');
    $componentTag = $_instance->getRenderedChildComponentTagName('hqhEU9d');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hqhEU9d');
} else {
    $response = \Livewire\Livewire::mount('account');
    $html = $response->html();
    $_instance->logRenderedChild('hqhEU9d', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    
   <div class="px-4 py-5">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('vote')->html();
} elseif ($_instance->childHasBeenRendered('9h2RHWC')) {
    $componentId = $_instance->getRenderedChildComponentId('9h2RHWC');
    $componentTag = $_instance->getRenderedChildComponentTagName('9h2RHWC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9h2RHWC');
} else {
    $response = \Livewire\Livewire::mount('vote');
    $html = $response->html();
    $_instance->logRenderedChild('9h2RHWC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/student/dashboard.blade.php ENDPATH**/ ?>