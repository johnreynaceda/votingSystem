<div>
    <?php $__empty_1 = true; $__currentLoopData = $partylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $partylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <h1 class="mt-5 font-semibold underline text-xl"><?php echo e(App\Models\Partylist::find($key)->partylist); ?>-PARTYLIST</h1>
    <div  data-flickity="{
        &quot;cellAlign&quot;: &quot;left&quot;,
        &quot;prevNextButtons&quot;: false,
        &quot;pageDots&quot;: false,
        &quot;contain&quot;: true,
        &quot;autoPlay&quot;: 2000,
        &quot;wrapAround&quot;: true}"  class="w-full  main-carousel flickity-enabled is-draggable mt-4 " tabindex="0">
        <?php $__currentLoopData = $partylist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-cell shadow-md relative  md:h-96 h-96 md:w-6/12 w-full ">
            <img src="<?php echo e(asset('images/sksu2.jpg')); ?>" class="absolute opacity-50" alt="">
           <div class="h-full relative flex items-center justify-center">
               <img src="<?php echo e(asset('/storage/candidates/' . $candidate->image->url)); ?>" class="h-80 shadow-md" alt="">
           </div>
            <div class="absolute bottom-3 left-3 bg-side text-white opacity-75 p-2">
                <h1 class="font-medium"><?php echo e($organization->organization); ?>-<?php echo e($organization->campus->campus); ?> CAMPUS</h1>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
       
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        
    <?php endif; ?>
  
</div>
<?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/livewire/welcome.blade.php ENDPATH**/ ?>