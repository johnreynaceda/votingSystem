
<?php $__env->startSection('content'); ?>
<div class="flex space-x-2 border-b border-green-500 items-center text-nav">
    <i class="material-icons md-36">safety_divider</i>
    <h1 class="text-xl font-medium ">Position</h1>
</div>
<div class="main-body mt-4">
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('position')->html();
} elseif ($_instance->childHasBeenRendered('dbfzueG')) {
    $componentId = $_instance->getRenderedChildComponentId('dbfzueG');
    $componentTag = $_instance->getRenderedChildComponentTagName('dbfzueG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dbfzueG');
} else {
    $response = \Livewire\Livewire::mount('position');
    $html = $response->html();
    $_instance->logRenderedChild('dbfzueG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/admin/position.blade.php ENDPATH**/ ?>