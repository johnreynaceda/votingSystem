<div>
    <div class="flex">
        <img src="<?php echo e(asset('images/sksulogo.png')); ?>" class="h-20" alt="">
        <div class="flex flex-col ml-2 justify-center">
            <h1 class="text-2xl font-medium">SULTAN KUDARAT STATE UNIVERISTY</h1>
            <h1 class="text-lg">Province of Sultan Kudarat, 9800, City of Tacurong, Philippines</h1>
        </div>
    </div>

    <div class="flex  mt-10 justify-end">
        <div class="flex flex-col">
            <h1 class="font-bold text-lg" style="color: #00993C">SKSU-OVS</h1>
        <h1>Online Voting System </h1>
        </div>
    </div>
    <div class="title mt-5">
        <h1 class="text-center text-xl font-bold"><?php echo e($organization->organization); ?>-<?php echo e($organization->campus->campus); ?> CAMPUS ELECTION</h1>
    </div>
    <div class="result mt-5 ">
       <?php $__empty_1 = true; $__currentLoopData = $partylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $partylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
       <h1 class="underline text-lg  font-medium"><?php echo e(App\Models\Partylist::find($key)->partylist); ?>-PARTYLIST</h1>
       <div class="candidates">
        <?php $__currentLoopData = $partylist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1><?php echo e($candidate->user->lastname.', '.$candidate->user->firstname.' '.$candidate->user->middlename[0].'.'); ?> = <?php echo e($candidate->finalVotes->count()); ?> votes</h1>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
           <h1 class="text-center"> No results of voting!</h1>
       <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/livewire/print-report.blade.php ENDPATH**/ ?>