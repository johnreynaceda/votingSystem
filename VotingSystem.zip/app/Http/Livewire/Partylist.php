<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Partylist extends Component
{
    public function render()
    {
        return view('livewire.admin.partylist.partylist');
    }
}
