<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Navbar extends Component
{
    public $showModal=false,$loginModal=false;
    public function render()
    {
        return view('livewire.navbar');
    }

    public function request(){
        $this->showModal=true;
    }
    public function login(){
        $this->loginModal=true;
    }
}
