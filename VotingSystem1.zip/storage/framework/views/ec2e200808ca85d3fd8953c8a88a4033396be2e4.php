<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination Navigation" class="flex space-x-2">
        
        <?php if($paginator->onFirstPage()): ?>
        <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 focus:outline-none bg-white hover:bg-side hover:text-white border border-gray-300 cursor-default leading-5 rounded-md">
            <?php echo __('pagination.previous'); ?>

        </span>
        <?php else: ?>
            <button type="button" wire:click="previousPage" rel="prev" class="relative inline-flex items-center  px-4 py-2 text-sm font-medium text-gray-700 hover:bg-side hover:text-white bg-white border border-gray-300 leading-5 rounded-md  focus:outline-none focus:shadow-outline-blue  active:bg-gray-100 transition ease-in-out duration-150">
                <?php echo __('pagination.previous'); ?>

            </button>
        <?php endif; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <button type="button" wire:click="nextPage" rel="next" class="relative inline-flex items-center  px-4 py-2 text-sm font-medium text-gray-700 hover:bg-side hover:text-white bg-white border border-gray-300 leading-5 rounded-md  focus:outline-none focus:shadow-outline-blue  active:bg-gray-100  transition ease-in-out duration-150">
                <?php echo __('pagination.next'); ?>

            </button>
        <?php else: ?>
        <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium focus:outline-none text-gray-500 hover:bg-side hover:text-white bg-white border border-gray-300 cursor-default leading-5 rounded-md">
            <?php echo __('pagination.next'); ?>

        </span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/layouts/pagination.blade.php ENDPATH**/ ?>