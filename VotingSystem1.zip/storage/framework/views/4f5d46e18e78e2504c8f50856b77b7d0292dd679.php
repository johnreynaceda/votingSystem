
<?php $__env->startSection('content'); ?>
<div class="mt-5 flex justify-end ">
    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
<a href="<?php echo e(route('logout')); ?>"
onclick="event.preventDefault();
            this.closest('form').submit();">
    <div class="flex border p-1 space-x-2 px-4 rounded-full bg-nav text-white  hover:bg-green-600  cursor-pointer border-gray-400 shadow-md">
        <i class="material-icons">logout</i>
        <h1>Sign-out</h1>
    </div>
</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student-base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/student/dashboard.blade.php ENDPATH**/ ?>