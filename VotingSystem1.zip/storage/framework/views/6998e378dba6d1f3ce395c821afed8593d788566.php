<div class=" relative  bg-gradient-to-r from-nav to-main h-16 flex space-x-2 items-center ">
    <img src="<?php echo e(asset('images/sksu2.jpg')); ?>"
        class=" opacity-25 top-0 object-cover inset-0 z-0 right-0 w-full h-full absolute " alt="">
    <div class="flex relative w-full">
        <div class="px-3 flex items-center space-x-3 opacity-100  w-10/12   ">
            <img src="<?php echo e(asset('images/sksulogo.png')); ?>" class="h-14" alt="">
            <h1 class="text-xl font-semibold text-white"> ONLINE VOTING SYSTEM</h1>
        </div>
        <div class="bg-white w-2/12 mx-3 my-2 space-x-1 p-1 flex px-4 shadow-md rounded-full">
            <div class=" w-2/12 flex justify-center items-center rounded-full">
                <i class="material-icons md-36">account_circle</i>
            </div>
            <div class=" underline text-side font-medium items-center flex w-9/12">
                <?php if(auth()->user()->isadmin == 1): ?>
                    <h1>ADMINISTRATOR</h1>
                <?php else: ?>
                <h1><?php echo e(auth()->user()->sidn); ?></h1>
                <?php endif; ?>
            </div>
            
                <a href="<?php echo e(route('login')); ?>">
                    <div  class="bg-nav cursor-pointer hover:bg-green-600 hover:text-ye  rounded-full border text-white flex justify-center items-center  border-side p-1  mr-3 ">
                        <i class="material-icons">vpn_key</i>
                    </div>
                </a>
                
            </div>
            
        </div>
        
    </div>
  
</div><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>