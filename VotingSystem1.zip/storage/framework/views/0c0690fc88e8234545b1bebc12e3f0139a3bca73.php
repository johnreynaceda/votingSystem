<div>
    <div class="flex space-x-3">
        <div class=" w-4/12">
        <div class=" border rounded-md shadow-md">
            <div class="header p-2 border-b space-x-2 flex text-side  border-green-500">
                <i class="material-icons">add_to_photos</i>
                <h1 class="font-medium">Add Campus</h1>
            </div>
            <div class="body p-2">
                <form action="">
                    <div class="mb-5 text-side">
                        <label for="">Campus:</label>
                        <input wire:model="campus_name" type="text" class="h-8 w-full outline-none focus:border-green-400 text-sm px-3 mt-1 focus:shadow-md rounded-sm border" placeholder="Enter Campus Name">
                        <?php $__errorArgs = ['campus_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700 text-sm error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="flex justify-end">
                        <div  wire:loading wire:target="save">
                            <div class="loadingio-spinner-dual-ball-7d9kijy1d27"><div class="ldio-es4i676yvyv">
                                <div></div><div></div><div></div>
                                </div></div>
                            </div>
                        <button wire:click.prevent="save" type="submit" class="bg-nav p-1 focus:outline-none rounded-full px-6 text-white shadow-md hover:bg-green-400">SAVE</button>
                    
                    </div>
                </form>
            </div>
        </div>
        </div>
    <div class=" w-8/12 border-l-2 overflow-y-visible border-green-500 p-2">
    <h1 class="font-medium text-side text-lg">LIST OF CAMPUSES</h1>
    <div  wire:loading wire:target="delete">
        <div class="loadingio-spinner-dual-ball-7d9kijy1d27"><div class="ldio-es4i676yvyv">
            <div></div><div></div><div></div>
            </div></div>
        </div>
    <div class=" mt-3 grid grid-cols-4  gap-4">
        <?php $__empty_1 = true; $__currentLoopData = $campus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-gradient-to-r from-main text-white  cursor-pointer via-green-400 to-main rounded-md shadow-md ">
            <div class="flex flex-col p-1  justify-center items-center">
                <div class="icon"><i class="material-icons md-48">house</i></div>
                <div class="text"><h1 class="font-medium h-12  text-center underline"><?php echo e($item->campus); ?> CAMPUS</h1></div>
            <div class="flex justify-end">
                <div class="border border-white  p-1 flex rounded-full ">
                    <div class="bg-print w-12 border-t border-b border-l hover:bg-yellow-500  border-white rounded-tl-full flex justify-center items-center rounded-bl-full "><i class="material-icons">edit</i></div>
                    <div wire:click="delete(<?php echo e($item->id); ?>)" class="bg-red-500 w-12 border-t border-b border-r hover:bg-red-600 rounded-tr-full flex justify-center items-center rounded-br-full "><i class="material-icons">delete</i></div>
                </div>
            </div>
            </div>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="underline text-side">No Campus Data!</div>
        <?php endif; ?>
      
      </div>
    </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/livewire/admin/campus.blade.php ENDPATH**/ ?>