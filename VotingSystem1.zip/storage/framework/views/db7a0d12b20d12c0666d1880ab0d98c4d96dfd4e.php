
<?php $__env->startSection('content'); ?>
<div class="flex space-x-2 border-b items-center text-side">
    <i class="material-icons md-36">dashboard</i>
    <h1 class="text-xl font-medium ">Dashboard</h1>
</div>
<div class="main-body mt-2">
    <h1>s</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\VotingSystem\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>