<?php return array (
  'campus' => 'App\\Http\\Livewire\\Campus',
  'navbar' => 'App\\Http\\Livewire\\Navbar',
  'organization' => 'App\\Http\\Livewire\\Organization',
  'partylist' => 'App\\Http\\Livewire\\Partylist',
  'position' => 'App\\Http\\Livewire\\Position',
  'student' => 'App\\Http\\Livewire\\Student',
  'user' => 'App\\Http\\Livewire\\User',
);