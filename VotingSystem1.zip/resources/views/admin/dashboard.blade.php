@extends('layouts.master')
@section('content')
<div class="flex space-x-2 border-b items-center text-side">
    <i class="material-icons md-36">dashboard</i>
    <h1 class="text-xl font-medium ">Dashboard</h1>
</div>
<div class="main-body mt-2">
    <h1>s</h1>
</div>
@endsection